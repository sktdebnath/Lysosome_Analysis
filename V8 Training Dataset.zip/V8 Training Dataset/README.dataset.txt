# Lysosome Segmentation > 2024-09-04 4:52pm
https://universe.roboflow.com/ant-s1guf/lysosome-segmentation-nbwd0

Provided by a Roboflow user
License: CC BY 4.0

